Python 3.7

Authors:
James Morillo
Matric: U1740375H
PH4419-COMPUTATIONAL PHYSICS
Final Project

Python 3.7, best to run in Spyder. Code is attached in case cannot copy paste from Annex.
Or visit 

"""
https://github.com/sadfool1/Computational_Physics/blob/master/Final%20Project/Final%20Code.py
"""



